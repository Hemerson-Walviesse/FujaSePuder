package com.hemerson.FujaSePuder.hordas;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.Monstro;

/**
 * Controla as hordas de uma fase: intervalo entre hordas, quantos monstros nascem
 * e como a dificuldade cresce a cada horda.
 */
public class GerenciadorDeHordas {

    public enum Estado { INTERVALO, EM_ANDAMENTO, CONCLUIDA }

    private final int totalHordas;
    private final float larguraMundo;
    private final float alturaMundo;

    private int hordaAtual = 0;
    private Estado estado = Estado.INTERVALO;
    private float tempoIntervalo = 2f;
    private int monstrosParaNascer = 0;
    private float tempoProximoSpawn = 0f;
    private boolean fimDeHordaPendente = false;

    public GerenciadorDeHordas(int totalHordas, float larguraMundo, float alturaMundo) {
        this.totalHordas = totalHordas;
        this.larguraMundo = larguraMundo;
        this.alturaMundo = alturaMundo;
    }

    public void atualizar(float delta, Array<Monstro> monstros, Vector2 posicaoHeroi) {
        switch (estado) {
            case INTERVALO:
                tempoIntervalo -= delta;
                if (tempoIntervalo <= 0) iniciarProximaHorda();
                break;

            case EM_ANDAMENTO:
                if (monstrosParaNascer > 0) {
                    tempoProximoSpawn -= delta;
                    if (tempoProximoSpawn <= 0) {
                        monstros.add(criarMonstro(posicaoHeroi));
                        monstrosParaNascer--;
                        tempoProximoSpawn = intervaloEntreSpawns();
                    }
                } else if (monstros.isEmpty()) {
                    fimDeHordaPendente = true;
                    if (hordaAtual >= totalHordas) {
                        estado = Estado.CONCLUIDA;
                    } else {
                        estado = Estado.INTERVALO;
                        tempoIntervalo = 3f;
                    }
                }
                break;

            case CONCLUIDA:
                break;
        }
    }

    private void iniciarProximaHorda() {
        hordaAtual++;
        monstrosParaNascer = 4 + hordaAtual * 2;   // horda 1 = 6 monstros, horda 10 = 24
        tempoProximoSpawn = 0f;
        estado = Estado.EM_ANDAMENTO;
    }

    private float intervaloEntreSpawns() {
        return Math.max(0.2f, 1.0f - hordaAtual * 0.07f);
    }

    /** Multiplicador de dificuldade: +15% de vida e dano por horda. */
    private float dificuldade() {
        return 1f + (hordaAtual - 1) * 0.15f;
    }

    private Monstro criarMonstro(Vector2 posicaoHeroi) {
        // Nasce logo fora da area visivel, em uma direcao aleatoria a partir do heroi
        float angulo = MathUtils.random(MathUtils.PI2);
        float distancia = 500f + MathUtils.random(100f);
        float x = MathUtils.clamp(posicaoHeroi.x + MathUtils.cos(angulo) * distancia, 0, larguraMundo);
        float y = MathUtils.clamp(posicaoHeroi.y + MathUtils.sin(angulo) * distancia, 0, alturaMundo);

        float d = dificuldade();

        // A partir da horda 5 aparecem tanques (marrons, lentos e resistentes)
        if (hordaAtual >= 5 && MathUtils.randomBoolean(0.15f)) {
            return new Monstro(x, y, 120 * d, 45 + hordaAtual * 2, 20 * d, 44, Color.BROWN, 0.40f);
        }
        // A partir da horda 3 aparecem corredores (verde-limao, rapidos e frageis)
        if (hordaAtual >= 3 && MathUtils.randomBoolean(0.25f)) {
            return new Monstro(x, y, 25 * d, 130 + hordaAtual * 4, 8 * d, 22, Color.LIME, 0.30f);
        }
        // Monstro comum (verde-escuro)
        return new Monstro(x, y, 50 * d, 70 + hordaAtual * 3, 10 * d, 30, Color.FOREST, 0.20f);
    }

    /** Monstro extra (dificuldade da horda atual), usado depois das hordas enquanto o altar nao enche. */
    public Monstro criarMonstroExtra(Vector2 posicaoHeroi) {
        return criarMonstro(posicaoHeroi);
    }

    /** Retorna true uma unica vez logo depois que uma horda termina. */
    public boolean consumirFimDeHorda() {
        boolean terminou = fimDeHordaPendente;
        fimDeHordaPendente = false;
        return terminou;
    }

    public int getHordaAtual() { return hordaAtual; }
    public int getTotalHordas() { return totalHordas; }
    public float getTempoIntervalo() { return tempoIntervalo; }
    public boolean emIntervalo() { return estado == Estado.INTERVALO; }
    public boolean concluida() { return estado == Estado.CONCLUIDA; }
}
