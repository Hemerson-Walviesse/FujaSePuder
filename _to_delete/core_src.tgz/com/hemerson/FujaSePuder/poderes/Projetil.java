package com.hemerson.FujaSePuder.poderes;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.Monstro;

/** Tiro, bola de fogo, jato de agua... qualquer coisa que voa e acerta monstros. */
public class Projetil {
    public static final int ATRAVESSA_TUDO = 9999;

    public final Poder origem;
    public final Vector2 posicao = new Vector2();
    public final Vector2 velocidade = new Vector2();
    public final float raio;
    public final float dano;
    public final Color cor;

    private int perfuracoes;          // quantos monstros ainda pode atravessar depois do primeiro
    private float distanciaRestante;
    private boolean ativo = true;
    private final Array<Monstro> jaAtingidos = new Array<>();

    public Projetil(Poder origem, Vector2 inicio, Vector2 direcao, float velocidadeEscalar,
                    float raio, float dano, float alcance, int perfuracoes, Color cor) {
        this.origem = origem;
        this.posicao.set(inicio);
        this.velocidade.set(direcao).nor().scl(velocidadeEscalar);
        this.raio = raio;
        this.dano = dano;
        this.distanciaRestante = alcance;
        this.perfuracoes = perfuracoes;
        this.cor = cor;
    }

    public void atualizar(float delta) {
        posicao.mulAdd(velocidade, delta);
        distanciaRestante -= velocidade.len() * delta;
        if (distanciaRestante <= 0) ativo = false;
    }

    public boolean podeAcertar(Monstro m) {
        return ativo && !jaAtingidos.contains(m, true) && m.posicao.dst(posicao) < raio + m.tamanho / 2f;
    }

    public void registrarAcerto(Monstro m) {
        jaAtingidos.add(m);
        if (perfuracoes <= 0) ativo = false;
        else perfuracoes--;
    }

    public boolean isAtivo() { return ativo; }
}
