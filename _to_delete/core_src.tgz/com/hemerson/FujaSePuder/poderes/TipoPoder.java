package com.hemerson.FujaSePuder.poderes;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.ClasseHeroi;

/** Todos os poderes/armas do jogo, separados por classe. */
public enum TipoPoder {

    // ---- Humano: armas
    PISTOLA(ClasseHeroi.HUMANO, 0, "Pistola", "Atira rapido no monstro mais proximo.", Color.LIGHT_GRAY),
    DUPLA(ClasseHeroi.HUMANO, 2, "Dupla", "Dispara 2 tiros por vez.", Color.WHITE),

    // ---- Demonio: poderes agressivos
    FOGO(ClasseHeroi.DEMONIO, 0, "Fogo", "Bola de fogo que explode em area e queima.", Color.ORANGE),
    AGUA(ClasseHeroi.DEMONIO, 1, "Agua", "Jato que atravessa os monstros e os deixa lentos.", Color.ROYAL),
    VENTO_DEMONIO(ClasseHeroi.DEMONIO, 2, "Vento", "Rajada que empurra os monstros para longe.", Color.SLATE),

    // ---- Anjo: poderes de precisao
    RAIO(ClasseHeroi.ANJO, 0, "Raio", "Acerta um monstro e ricocheteia em outros.", Color.YELLOW),
    VENTO_ANJO(ClasseHeroi.ANJO, 2, "Vento", "Laminas de vento giram em volta de voce.", Color.TEAL),
    LUZ(ClasseHeroi.ANJO, 1, "Luz", "Feixe que atravessa, causa muito dano e atordoa.", Color.WHITE);

    public final ClasseHeroi classe;
    /** Papel do poder: 0 = dano, 1 = controle, 2 = area. Usado na equivalencia ao trocar de classe. */
    public final int papel;
    public final String nome;
    public final String descricao;
    public final Color cor;

    TipoPoder(ClasseHeroi classe, int papel, String nome, String descricao, Color cor) {
        this.classe = classe;
        this.papel = papel;
        this.nome = nome;
        this.descricao = descricao;
        this.cor = cor;
    }

    public Poder criar() {
        switch (this) {
            case PISTOLA:       return new PoderPistola();
            case DUPLA:         return new PoderDupla();
            case FOGO:          return new PoderFogo();
            case AGUA:          return new PoderAgua();
            case VENTO_DEMONIO: return new PoderVentoDemonio();
            case RAIO:          return new PoderRaio();
            case VENTO_ANJO:    return new PoderVentoAnjo();
            case LUZ:           return new PoderLuz();
            default: throw new IllegalStateException("Poder sem implementacao: " + this);
        }
    }

    /** Poder da classe destino com o mesmo papel (ex.: Raio -> Fogo). */
    public static TipoPoder equivalente(TipoPoder origem, ClasseHeroi destino) {
        for (TipoPoder t : values()) {
            if (t.classe == destino && t.papel == origem.papel) return t;
        }
        return null;
    }

    public static Array<TipoPoder> daClasse(ClasseHeroi classe) {
        Array<TipoPoder> lista = new Array<>();
        for (TipoPoder t : values()) {
            if (t.classe == classe) lista.add(t);
        }
        return lista;
    }
}
