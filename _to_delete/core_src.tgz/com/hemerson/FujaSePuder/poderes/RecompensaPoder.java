package com.hemerson.FujaSePuder.poderes;

import com.badlogic.gdx.graphics.Color;
import com.hemerson.FujaSePuder.entidades.Heroi;
import com.hemerson.FujaSePuder.itens.Recompensa;

/** Carta de "novo poder" ou "subir nivel de um poder". */
public class RecompensaPoder implements Recompensa {
    private final TipoPoder tipo;
    private final boolean novo;
    private final int proximoNivel;

    public RecompensaPoder(TipoPoder tipo, boolean novo, int proximoNivel) {
        this.tipo = tipo;
        this.novo = novo;
        this.proximoNivel = proximoNivel;
    }

    @Override public String getNome() {
        return novo ? "NOVO: " + tipo.nome : tipo.nome + " Nv " + proximoNivel;
    }

    @Override public String getDescricao() {
        return novo ? tipo.descricao : "Sobe de nivel: mais dano e recarga mais rapida.";
    }

    @Override public Color getCor() { return tipo.cor; }

    @Override
    public void aplicar(Heroi heroi) {
        if (novo) {
            heroi.adicionarPoder(tipo.criar());
        } else {
            Poder p = heroi.getPoder(tipo);
            if (p != null) p.subirNivel();
        }
    }
}
