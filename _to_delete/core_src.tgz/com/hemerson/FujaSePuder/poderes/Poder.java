package com.hemerson.FujaSePuder.poderes;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.Heroi;
import com.hemerson.FujaSePuder.entidades.Monstro;

/**
 * Base de todos os poderes/armas. Cada poder dispara sozinho quando recarrega.
 * Obs.: use loops com indice (for int i) nas listas de monstros, nunca for-each,
 * porque o Array do libGDX nao permite dois for-each aninhados na mesma lista.
 */
public abstract class Poder {

    public static final int NIVEL_MAXIMO = 5;

    public final TipoPoder tipo;
    protected int nivel = 1;
    protected float recarga = 0f;

    protected Poder(TipoPoder tipo) {
        this.tipo = tipo;
    }

    public void atualizar(float delta, Heroi heroi, Array<Monstro> monstros, Array<Projetil> projeteis) {
        atualizarEfeitos(delta);
        recarga -= delta;
        if (recarga <= 0) {
            boolean usou = usar(heroi, monstros, projeteis);
            recarga = usou ? intervaloBase() * fatorRecarga(heroi) : 0.1f; // sem alvo: tenta de novo logo
        }
    }

    /** Segundos entre usos, no nivel 1 e sem buffs. */
    protected abstract float intervaloBase();

    /** Dispara o poder. Retorna false se nao tinha alvo. */
    protected abstract boolean usar(Heroi heroi, Array<Monstro> monstros, Array<Projetil> projeteis);

    /** Chamado quando um projetil deste poder acerta um monstro. */
    public void aoAcertar(Projetil projetil, Monstro alvo, Heroi heroi, Array<Monstro> monstros) {
        ferir(heroi, alvo, projetil.dano);
    }

    protected void atualizarEfeitos(float delta) { }
    public void desenharLinhas(ShapeRenderer shapes, Heroi heroi) { }
    public void desenharFormas(ShapeRenderer shapes, Heroi heroi) { }

    // ------------------------------------------------------------------ niveis

    public int getNivel() { return nivel; }
    public boolean nivelMaximo() { return nivel >= NIVEL_MAXIMO; }
    public void subirNivel() { if (nivel < NIVEL_MAXIMO) nivel++; }

    /** Cada nivel: +25% de dano. Tambem aplica os buffs de dano do heroi. */
    protected float dano(Heroi heroi, float base) {
        return base * (1f + 0.25f * (nivel - 1)) * heroi.fatorDano();
    }

    /** Cada nivel: recarrega 8% mais rapido. Tambem aplica os buffs de velocidade de ataque. */
    protected float fatorRecarga(Heroi heroi) {
        return (1f - 0.08f * (nivel - 1)) * heroi.fatorVelocidadeAtaque();
    }

    protected float alcance(Heroi heroi, float base) {
        return base * heroi.fatorAlcance();
    }

    // ---------------------------------------------------------------- utilitarios

    protected static void ferir(Heroi heroi, Monstro monstro, float quantidade) {
        monstro.receberDano(quantidade);
        heroi.aoCausarDano(quantidade);
    }

    protected static Monstro maisProximo(Vector2 de, Array<Monstro> monstros, float alcanceMaximo, Array<Monstro> ignorar) {
        Monstro escolhido = null;
        float menor = alcanceMaximo;
        for (int i = 0; i < monstros.size; i++) {
            Monstro m = monstros.get(i);
            if (!m.estaVivo() || (ignorar != null && ignorar.contains(m, true))) continue;
            float d = m.posicao.dst(de);
            if (d <= menor) {
                menor = d;
                escolhido = m;
            }
        }
        return escolhido;
    }
}
