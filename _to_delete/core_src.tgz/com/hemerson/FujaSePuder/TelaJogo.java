package com.hemerson.FujaSePuder;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.hemerson.FujaSePuder.entidades.Altar;
import com.hemerson.FujaSePuder.entidades.Boss;
import com.hemerson.FujaSePuder.entidades.ClasseHeroi;
import com.hemerson.FujaSePuder.entidades.Heroi;
import com.hemerson.FujaSePuder.entidades.Meteoro;
import com.hemerson.FujaSePuder.entidades.ProjetilInimigo;
import com.hemerson.FujaSePuder.entidades.Monstro;
import com.hemerson.FujaSePuder.hordas.GerenciadorDeHordas;
import com.hemerson.FujaSePuder.itens.ItemDrop;
import com.hemerson.FujaSePuder.itens.Recompensa;
import com.hemerson.FujaSePuder.itens.RecompensaElemento;
import com.hemerson.FujaSePuder.itens.RecompensaPerderBuff;
import com.hemerson.FujaSePuder.itens.RecompensaTrocaClasse;
import com.hemerson.FujaSePuder.poderes.RecompensaEpico;
import com.hemerson.FujaSePuder.itens.TipoBuff;
import com.hemerson.FujaSePuder.poderes.ElementoArma;
import com.hemerson.FujaSePuder.itens.SorteioRecompensas;
import com.hemerson.FujaSePuder.poderes.Poder;
import com.hemerson.FujaSePuder.poderes.Projetil;
import com.hemerson.FujaSePuder.poderes.RecompensaPoder;
import com.hemerson.FujaSePuder.poderes.TipoPoder;

/**
 * Tela da fase. O ataque basico e os poderes atacam sozinhos.
 * O primeiro poder e escolhido ao terminar a horda 1.
 * Desktop: WASD/setas para andar, ESPACO para a habilidade especial.
 * Android: toque e segure para andar, toque no botao redondo para a habilidade.
 */
public class TelaJogo extends ScreenAdapter {

    private static final float LARGURA = 800f;
    private static final float ALTURA = 480f;
    private static final int HORDAS_POR_FASE = 10;

    // O mundo e maior que a tela: a camera segue o heroi
    private static final float MUNDO_LARGURA = 1600f;
    private static final float MUNDO_ALTURA = 960f;
    private static final float TAMANHO_GRADE = 80f;

    // Botao da habilidade (usado no celular, mas tambem funciona com clique)
    private static final float BOTAO_X = LARGURA - 70f;
    private static final float BOTAO_Y = 70f;
    private static final float BOTAO_RAIO = 45f;

    // Cards da escolha de recompensa
    private static final float CARD_LARGURA = 210f;
    private static final float CARD_ALTURA = 200f;
    private static final float CARD_PEQUENO_LARGURA = 180f; // usado quando ha mais de 3 opcoes
    private static final float CARD_PEQUENO_ALTURA = 80f;

    /** Horda em que o Humano escolhe o elemento da arma (Fogo, Gelo ou Laser). */
    private static final int HORDA_ESCOLHA_ELEMENTO = 3;

    private enum ModoEscolha { RECOMPENSA, PRIMEIRO_PODER, ELEMENTO, TROCA_ELEMENTO, PERDER_BUFF, BOSS }

    // Drops de vida dos monstros
    private static final int MAX_DROPS_POR_HORDA = 1;
    private static final float CURA_DO_DROP = 25f;

    // Altar e boss
    // Sacrificios POR ALTAR: 30 na fase 1, +10 por fase, maximo 80
    private static final int SACRIFICIOS_FASE_1 = 30;
    private static final int SACRIFICIOS_POR_FASE = 10;
    private static final int SACRIFICIOS_MAXIMO = 80;
    private static final float VIDA_BOSS = 3500f;
    private static final int QUANTIDADE_ALTARES = 2; // cada altar precisa da quantidade inteira da fase
    private static final float INTERVALO_MONSTRO_EXTRA = 0.8f; // depois das hordas, enquanto o altar nao enche
    private static final int MAX_MONSTROS_EXTRA = 25;

    // Botao do epico (tecla E)
    private static final float BOTAO_EPICO_X = BOTAO_X - 105f;
    private static final float BOTAO_EPICO_RAIO = 38f;

    private final FujaSePuder jogo;
    private final ClasseHeroi classeInicial;

    private final OrthographicCamera camera = new OrthographicCamera();
    private final FitViewport viewport = new FitViewport(LARGURA, ALTURA, camera);
    private final OrthographicCamera cameraHud = new OrthographicCamera();
    private final FitViewport viewportHud = new FitViewport(LARGURA, ALTURA, cameraHud);
    private final ShapeRenderer shapes = new ShapeRenderer();
    private final SpriteBatch batch = new SpriteBatch();
    private final BitmapFont fonte = new BitmapFont();

    private final Vector3 toque = new Vector3();
    private final Vector3 toqueHud = new Vector3();
    private final Vector2 movimento = new Vector2();
    private final Color corTemp = new Color();
    private final Array<Vector2> linhasAtaque = new Array<>();
    private final Array<Monstro> atingidos = new Array<>();
    private float tempoEfeitoAtaque;

    private Heroi heroi;
    private Array<Monstro> monstros;
    private Array<Projetil> projeteis;
    private GerenciadorDeHordas hordas;
    private int abates;

    // Drops e recompensas
    private Array<ItemDrop> drops;
    private final Array<Recompensa> opcoes = new Array<>();
    private final Array<Rectangle> cards = new Array<>();
    private ModoEscolha modo = ModoEscolha.RECOMPENSA;
    private int escolhasPendentes;
    private int dropsNestaHorda;
    private int hordaDosDrops;

    // Altar / boss / fim de fase
    private final Array<Altar> altares = new Array<>();
    private Array<ProjetilInimigo> projeteisInimigos;
    private Array<Meteoro> meteoros;
    private Boss boss;
    private boolean bossDerrotado;
    private boolean recompensaBossPendente;
    private boolean faseConcluida;
    private boolean modoInfinito;       // depois da fase: continua vindo monstro (para testar o epico)
    private float tempoMonstroExtra;
    private int faseAtual = 1;          // vai subir quando as fases 2 a 5 existirem
    private float tempoAvisoAltar;      // mostra "O altar mudou de lugar!"

    /** Lugares possiveis dos altares (cantos e meio das bordas, longe do inicio no centro do mapa). */
    private static final float[][] POSICOES_ALTAR = {
        { 300, 250 }, { 1300, 250 }, { 300, 710 }, { 1300, 710 },
        { 800, 150 }, { 800, 810 }, { 200, 480 }, { 1400, 480 } };

    public TelaJogo(FujaSePuder jogo, ClasseHeroi classe) {
        this.jogo = jogo;
        this.classeInicial = classe;
        reiniciar();
    }

    private void reiniciar() {
        heroi = new Heroi(MUNDO_LARGURA / 2f, MUNDO_ALTURA / 2f, classeInicial);
        monstros = new Array<>();
        projeteis = new Array<>();
        hordas = new GerenciadorDeHordas(HORDAS_POR_FASE, MUNDO_LARGURA, MUNDO_ALTURA);
        abates = 0;
        drops = new Array<>();
        opcoes.clear();
        escolhasPendentes = 0;
        dropsNestaHorda = 0;
        hordaDosDrops = 0;
        modo = ModoEscolha.RECOMPENSA;
        cards.clear();
        linhasAtaque.clear();
        tempoEfeitoAtaque = 0f;

        // Altares em lugares diferentes; CADA um precisa dos sacrificios da fase (30 na fase 1, 40 na 2...)
        altares.clear();
        int porAltar = sacrificiosDaFase(faseAtual);
        for (int i = 0; i < QUANTIDADE_ALTARES; i++) {
            float[] pos = posicaoLivreParaAltar(null);
            altares.add(new Altar(pos[0], pos[1], porAltar));
        }
        tempoAvisoAltar = 0f;
        projeteisInimigos = new Array<>();
        meteoros = new Array<>();
        boss = null;
        bossDerrotado = false;
        recompensaBossPendente = false;
        faseConcluida = false;
        modoInfinito = false;
        tempoMonstroExtra = 0f;
        atualizarCamera();
    }

    @Override
    public void render(float delta) {
        delta = Math.min(delta, 1 / 30f); // evita saltos se o jogo travar por um instante

        if (escolhendoRecompensa()) {
            processarEscolha(); // jogo pausado enquanto escolhe
        } else if (heroi.estaVivo() && !faseConcluida) {
            atualizar(delta);
        } else if (faseConcluida && heroi.estaVivo() && Gdx.input.isKeyJustPressed(Input.Keys.C)) {
            faseConcluida = false;
            modoInfinito = true;
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            reiniciar();
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE) || Gdx.input.justTouched()) {
            jogo.setScreen(new TelaSelecao(jogo));
            dispose();
            return;
        }

        desenhar();
    }

    // ------------------------------------------------------------------ logica

    private void atualizar(float delta) {
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || (Gdx.input.justTouched() && tocandoNoBotao())) {
            heroi.usarHabilidade(monstros);
        }
        if (heroi.epico != null && (Gdx.input.isKeyJustPressed(Input.Keys.E)
            || (Gdx.input.justTouched() && tocandoNoBotaoEpico()))) {
            heroi.epico.ativar();
        }

        moverHeroi(delta);
        atualizarCamera();
        heroi.atualizar(delta);
        hordas.atualizar(delta, monstros, heroi.posicao);

        // Recompensa garantida ao terminar cada horda (menos a ultima, que encerra a fase)
        if (hordas.consumirFimDeHorda() && !hordas.concluida()) escolhasPendentes++;
        atualizarAltarEBoss(delta);
        atualizarAtaquesDoBoss(delta);

        for (int i = 0; i < monstros.size; i++) {
            Monstro m = monstros.get(i);
            m.atualizar(delta, heroi.posicao);
            if (m.colideCom(heroi)) heroi.receberDano(m.dano);
        }

        atacarAutomaticamente();
        atualizarPoderes(delta);
        removerMortos();

        if (tempoEfeitoAtaque > 0) tempoEfeitoAtaque -= delta;
        if (tempoAvisoAltar > 0) tempoAvisoAltar -= delta;
        atualizarDrops(delta);

        if (recompensaBossPendente && !escolhendoRecompensa()) abrirEscolhaBoss();
        if (bossDerrotado && !modoInfinito && !recompensaBossPendente && !escolhendoRecompensa()
            && escolhasPendentes == 0 && heroi.penalidadesPendentes == 0) {
            faseConcluida = true;
        }
    }

    /** Distancia minima entre altares: nunca aparecem um perto do outro. */
    private static final float DISTANCIA_MINIMA_ALTARES = 700f;

    /**
     * Sorteia um lugar longe (>= 700) de todos os altares atuais. Inclui o lugar do proprio altar que
     * esta se movendo, entao ele tambem sempre vai para longe de onde estava.
     * Se nenhum lugar servir, usa o mais distante possivel.
     */
    private float[] posicaoLivreParaAltar(Altar ignorar) {
        Array<float[]> validas = new Array<>();
        float[] maisDistante = POSICOES_ALTAR[0];
        float melhorDistancia = -1f;
        for (float[] p : POSICOES_ALTAR) {
            float menor = Float.MAX_VALUE;
            for (int i = 0; i < altares.size; i++) {
                Altar a = altares.get(i);
                menor = Math.min(menor, Vector2.dst(p[0], p[1], a.posicao.x, a.posicao.y));
            }
            if (menor >= DISTANCIA_MINIMA_ALTARES) validas.add(p);
            if (menor > melhorDistancia) {
                melhorDistancia = menor;
                maisDistante = p;
            }
        }
        return validas.size > 0 ? validas.random() : maisDistante;
    }

    private void moverAltar(Altar altar) {
        float[] nova = posicaoLivreParaAltar(altar);
        altar.mover(nova[0], nova[1]);
        tempoAvisoAltar = 2.5f;
    }

    private boolean altaresCompletos() {
        for (int i = 0; i < altares.size; i++) if (!altares.get(i).completo()) return false;
        return true;
    }

    private int totalSacrificios() {
        int t = 0;
        for (int i = 0; i < altares.size; i++) t += altares.get(i).getSacrificios();
        return t;
    }

    private int totalNecessario() {
        int t = 0;
        for (int i = 0; i < altares.size; i++) t += altares.get(i).getNecessario();
        return t;
    }

    /** Tiros e meteoros do boss. */
    private void atualizarAtaquesDoBoss(float delta) {
        if (boss != null && boss.estaVivo()) {
            if (boss.consumirRajada()) {
                int n = boss.enraivecido() ? 16 : 12;
                float inicio = MathUtils.random(360f);
                for (int k = 0; k < n; k++) {
                    projeteisInimigos.add(new ProjetilInimigo(boss.posicao, inicio + k * 360f / n, 230f, 9f, 15f, 750f));
                }
            }
            if (boss.consumirMeteoros()) {
                int n = boss.enraivecido() ? 7 : 5;
                meteoros.add(new Meteoro(heroi.posicao.x, heroi.posicao.y, 45f, 20f)); // um sempre em cima de voce
                for (int k = 1; k < n; k++) {
                    float x = MathUtils.clamp(heroi.posicao.x + MathUtils.random(-200f, 200f), 0, MUNDO_LARGURA);
                    float y = MathUtils.clamp(heroi.posicao.y + MathUtils.random(-200f, 200f), 0, MUNDO_ALTURA);
                    meteoros.add(new Meteoro(x, y, 45f, 20f));
                }
            }
        }

        for (int i = projeteisInimigos.size - 1; i >= 0; i--) {
            ProjetilInimigo p = projeteisInimigos.get(i);
            p.atualizar(delta);
            if (p.acertou(heroi)) {
                heroi.receberDano(p.dano);
                projeteisInimigos.removeIndex(i);
            } else if (!p.ativo()) {
                projeteisInimigos.removeIndex(i);
            }
        }
        for (int i = meteoros.size - 1; i >= 0; i--) {
            Meteoro m = meteoros.get(i);
            if (m.atualizar(delta) && m.atinge(heroi)) heroi.receberDano(m.dano);
            if (m.terminou()) meteoros.removeIndex(i);
        }
    }

    /** 30 na fase 1, 40 na 2, 50 na 3... ate no maximo 80. */
    private static int sacrificiosDaFase(int fase) {
        return Math.min(SACRIFICIOS_MAXIMO, SACRIFICIOS_FASE_1 + SACRIFICIOS_POR_FASE * (fase - 1));
    }

    /** Depois das hordas: se o altar encheu, invoca o boss; senao continuam vindo monstros. */
    private void atualizarAltarEBoss(float delta) {
        boolean precisaDeMonstros = modoInfinito || (hordas.concluida() && boss == null && !bossDerrotado && !altaresCompletos());
        if (hordas.concluida() && boss == null && !bossDerrotado && altaresCompletos()) {
            Altar a = altares.first();
            boss = new Boss(a.posicao.x, a.posicao.y, "Guardiao do Altar", VIDA_BOSS);
            monstros.add(boss);
            return;
        }
        if (precisaDeMonstros) {
            tempoMonstroExtra -= delta;
            if (tempoMonstroExtra <= 0 && monstros.size < MAX_MONSTROS_EXTRA) {
                monstros.add(hordas.criarMonstroExtra(heroi.posicao));
                tempoMonstroExtra = INTERVALO_MONSTRO_EXTRA;
            }
        }
    }

    private void abrirEscolhaBoss() {
        recompensaBossPendente = false;
        opcoes.clear();
        modo = ModoEscolha.BOSS;
        opcoes.add(new RecompensaEpico(heroi));
        if (!heroi.jaTrocouDeClasse) {
            opcoes.addAll(RecompensaTrocaClasse.opcoesPara(heroi));   // bosses 1 e 3
        } else {
            opcoes.addAll(SorteioRecompensas.sortear(heroi, 2));      // depois viram 2 raros
        }
        montarCards(opcoes.size);
    }

    private void atacarAutomaticamente() {
        if (!heroi.podeAtacar()) return;

        // Escolhe os N monstros mais proximos dentro do alcance (N = 2 para o Anjo)
        atingidos.clear();
        for (int i = 0; i < heroi.alvosPorAtaque(); i++) {
            Monstro maisProximo = null;
            float menorDistancia = heroi.alcanceAtaque;
            for (int j = 0; j < monstros.size; j++) {
                Monstro m = monstros.get(j);
                if (atingidos.contains(m, true)) continue;
                float d = m.posicao.dst(heroi.posicao);
                if (d <= menorDistancia) {
                    menorDistancia = d;
                    maisProximo = m;
                }
            }
            if (maisProximo == null) break;
            atingidos.add(maisProximo);
        }
        if (atingidos.isEmpty()) return;

        float dano = heroi.getDanoAtual();
        linhasAtaque.clear();
        for (int i = 0; i < atingidos.size; i++) {
            Monstro m = atingidos.get(i);
            m.receberDano(dano);
            heroi.aoCausarDano(dano);
            linhasAtaque.add(new Vector2(m.posicao));
        }
        heroi.registrarAtaque();
        tempoEfeitoAtaque = 0.1f;
    }

    private void atualizarPoderes(float delta) {
        if (heroi.epico != null) heroi.epico.atualizar(delta, heroi, monstros);
        for (int i = 0; i < heroi.poderes.size; i++) {
            heroi.poderes.get(i).atualizar(delta, heroi, monstros, projeteis);
        }

        for (int i = projeteis.size - 1; i >= 0; i--) {
            Projetil p = projeteis.get(i);
            p.atualizar(delta);
            for (int j = 0; j < monstros.size && p.isAtivo(); j++) {
                Monstro m = monstros.get(j);
                if (m.estaVivo() && p.podeAcertar(m)) {
                    p.registrarAcerto(m);
                    p.origem.aoAcertar(p, m, heroi, monstros);
                }
            }
            if (!p.isAtivo()) projeteis.removeIndex(i);
        }
    }

    /** Centraliza a camera no heroi, sem mostrar nada fora do mundo. */
    private void atualizarCamera() {
        float meioL = LARGURA / 2f;
        float meioA = ALTURA / 2f;
        camera.position.set(
            MathUtils.clamp(heroi.posicao.x, meioL, MUNDO_LARGURA - meioL),
            MathUtils.clamp(heroi.posicao.y, meioA, MUNDO_ALTURA - meioA), 0);
        camera.update();
    }

    /** Diz se o toque atual caiu no botao da habilidade (coordenadas do HUD). */
    private boolean tocandoNoBotao() {
        toqueHud.set(Gdx.input.getX(), Gdx.input.getY(), 0);
        viewportHud.unproject(toqueHud);
        return Vector2.dst(toqueHud.x, toqueHud.y, BOTAO_X, BOTAO_Y) <= BOTAO_RAIO;
    }

    /** Diz se o toque atual caiu no botao do epico. */
    private boolean tocandoNoBotaoEpico() {
        if (heroi.epico == null) return false;
        toqueHud.set(Gdx.input.getX(), Gdx.input.getY(), 0);
        viewportHud.unproject(toqueHud);
        return Vector2.dst(toqueHud.x, toqueHud.y, BOTAO_EPICO_X, BOTAO_Y) <= BOTAO_EPICO_RAIO;
    }

    private void moverHeroi(float delta) {
        movimento.setZero();

        if (Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP))    movimento.y += 1;
        if (Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.DOWN))  movimento.y -= 1;
        if (Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT))  movimento.x -= 1;
        if (Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.RIGHT)) movimento.x += 1;

        // Toque (Android) ou clique segurado (desktop): anda em direcao ao ponto tocado
        if (Gdx.input.isTouched() && !tocandoNoBotao() && !tocandoNoBotaoEpico()) {
            toque.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewport.unproject(toque); // coordenadas do mundo
            movimento.set(toque.x - heroi.posicao.x, toque.y - heroi.posicao.y);
            if (movimento.len() < 5f) movimento.setZero();
        }

        if (!movimento.isZero()) {
            movimento.nor().scl(heroi.velocidade * delta);
            heroi.posicao.add(movimento);
        }

        float meio = heroi.tamanho / 2f;
        heroi.posicao.x = MathUtils.clamp(heroi.posicao.x, meio, MUNDO_LARGURA - meio);
        heroi.posicao.y = MathUtils.clamp(heroi.posicao.y, meio, MUNDO_ALTURA - meio);
    }

    private void removerMortos() {
        for (int i = monstros.size - 1; i >= 0; i--) {
            if (!monstros.get(i).estaVivo()) {
                Monstro morto = monstros.removeIndex(i);
                if (morto instanceof Boss) {
                    bossDerrotado = true;
                    recompensaBossPendente = true;
                    projeteisInimigos.clear();
                    meteoros.clear();
                    continue;
                }
                abates++;

                // Sacrificio: monstro morto dentro do altar (antes do boss aparecer)
                if (boss == null && !bossDerrotado) {
                    for (int a = 0; a < altares.size; a++) {
                        Altar altar = altares.get(a);
                        if (altar.completo() || !altar.contem(morto.posicao)) continue;
                        altar.registrarSacrificio();
                        // Ao chegar em 1/3 e 2/3 do proprio altar, ele vai para outro lugar
                        if (!altar.completo() && altar.etapa() > altar.etapaMovida) {
                            altar.etapaMovida = altar.etapa();
                            moverAltar(altar);
                        }
                        break;
                    }
                }

                if (hordas.getHordaAtual() != hordaDosDrops) {
                    hordaDosDrops = hordas.getHordaAtual();
                    dropsNestaHorda = 0;
                }
                // Drop de vida: no maximo 1 por horda
                if (dropsNestaHorda < MAX_DROPS_POR_HORDA && MathUtils.randomBoolean(morto.chanceDrop)) {
                    drops.add(new ItemDrop(morto.posicao.x, morto.posicao.y));
                    dropsNestaHorda++;
                }
            }
        }
    }

    // ------------------------------------------------------- drops / recompensas

    private void atualizarDrops(float delta) {
        for (int i = drops.size - 1; i >= 0; i--) {
            ItemDrop d = drops.get(i);
            d.atualizar(delta);
            if (d.colideCom(heroi)) {
                drops.removeIndex(i);
                heroi.curar(CURA_DO_DROP);
            } else if (d.expirou()) {
                drops.removeIndex(i);
            }
        }
        if (escolhasPendentes > 0 && !escolhendoRecompensa()) abrirEscolhaDeHorda();
    }

    private boolean escolhendoRecompensa() {
        return opcoes.size > 0;
    }

    /** Escolha de fim de horda: primeiro poder, elemento (Humano) ou recompensa normal. */
    private void abrirEscolhaDeHorda() {
        escolhasPendentes--;
        opcoes.clear();
        if (heroi.poderes.size == 0) {
            modo = ModoEscolha.PRIMEIRO_PODER;
            for (TipoPoder t : TipoPoder.daClasse(heroi.classe)) opcoes.add(new RecompensaPoder(t, true, 1));
        } else if (heroi.classe == ClasseHeroi.HUMANO && heroi.elemento == null
                   && hordas.getHordaAtual() >= HORDA_ESCOLHA_ELEMENTO) {
            abrirEscolhaElemento(false);
            return;
        } else {
            modo = ModoEscolha.RECOMPENSA;
            opcoes.addAll(SorteioRecompensas.sortear(heroi, 3));
        }
        montarCards(opcoes.size);
    }

    private void abrirEscolhaElemento(boolean troca) {
        opcoes.clear();
        modo = troca ? ModoEscolha.TROCA_ELEMENTO : ModoEscolha.ELEMENTO;
        for (ElementoArma e : ElementoArma.values()) {
            if (e != heroi.elemento) opcoes.add(new RecompensaElemento(e));
        }
        montarCards(opcoes.size);
    }

    /** Monta as cartas da penalidade. Retorna false se o heroi nao tem nada para perder. */
    private boolean abrirPerderBuff() {
        opcoes.clear();
        modo = ModoEscolha.PERDER_BUFF;

        Array<TipoBuff> vistos = new Array<>();
        for (int i = 0; i < heroi.buffs.size; i++) {
            TipoBuff b = heroi.buffs.get(i);
            if (vistos.contains(b, true)) continue;
            vistos.add(b);
            int quantidade = 0;
            for (int k = 0; k < heroi.buffs.size; k++) if (heroi.buffs.get(k) == b) quantidade++;
            opcoes.add(RecompensaPerderBuff.doBuff(b, quantidade));
        }
        if (heroi.elemento != null) {
            for (int espaco = 0; espaco < 2; espaco++) {
                if (heroi.niveisElemento[espaco] > 0) opcoes.add(RecompensaPerderBuff.daMelhoria(heroi, espaco));
            }
        }
        if (opcoes.size > 12) opcoes.truncate(12);
        if (opcoes.isEmpty()) return false;
        montarCards(opcoes.size);
        return true;
    }

    /** Depois de cada escolha: resolve pedidos de troca, penalidades e escolhas de horda pendentes. */
    private void proximaEscolha() {
        opcoes.clear();
        if (heroi.pedidoTrocaElemento) {
            heroi.pedidoTrocaElemento = false;
            abrirEscolhaElemento(true);
            return;
        }
        if (heroi.penalidadesPendentes > 0) {
            if (abrirPerderBuff()) return;
            heroi.penalidadesPendentes = 0; // nao tinha buffs para perder
        }
        if (escolhasPendentes > 0) abrirEscolhaDeHorda();
    }

    private void montarCards(int quantidade) {
        cards.clear();
        if (quantidade <= 3) {
            float espaco = (LARGURA - quantidade * CARD_LARGURA) / (quantidade + 1);
            for (int i = 0; i < quantidade; i++) {
                cards.add(new Rectangle(espaco + i * (CARD_LARGURA + espaco), 120, CARD_LARGURA, CARD_ALTURA));
            }
        } else {
            int colunas = 4;
            float espaco = (LARGURA - colunas * CARD_PEQUENO_LARGURA) / (colunas + 1);
            for (int i = 0; i < quantidade; i++) {
                int col = i % colunas;
                int linha = i / colunas;
                cards.add(new Rectangle(espaco + col * (CARD_PEQUENO_LARGURA + espaco),
                    300 - linha * (CARD_PEQUENO_ALTURA + 15), CARD_PEQUENO_LARGURA, CARD_PEQUENO_ALTURA));
            }
        }
    }

    private void processarEscolha() {
        int escolha = -1;
        for (int k = 0; k < 9; k++) {
            if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1 + k)) escolha = k;
        }
        if (Gdx.input.justTouched()) {
            toqueHud.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewportHud.unproject(toqueHud);
            for (int i = 0; i < cards.size; i++) {
                if (cards.get(i).contains(toqueHud.x, toqueHud.y)) escolha = i;
            }
        }

        if (escolha >= 0 && escolha < opcoes.size) {
            opcoes.get(escolha).aplicar(heroi);
            proximaEscolha();
        }
    }

    // ---------------------------------------------------------------- desenho

    private void desenhar() {
        ScreenUtils.clear(0.10f, 0.10f, 0.12f, 1f);

        // Mundo (segue o heroi)
        viewport.apply();
        shapes.setProjectionMatrix(camera.combined);
        desenharLinhasMundo();
        desenharFormasMundo();

        // HUD (fixo na tela)
        viewportHud.apply();
        shapes.setProjectionMatrix(cameraHud.combined);
        batch.setProjectionMatrix(cameraHud.combined);
        desenharHud();
        desenharTextos();
        if (escolhendoRecompensa()) desenharEscolha();
    }

    private void desenharLinhasMundo() {
        shapes.begin(ShapeRenderer.ShapeType.Line);

        // Grade do chao e borda do mundo
        shapes.setColor(0.16f, 0.16f, 0.19f, 1f);
        for (float x = 0; x <= MUNDO_LARGURA; x += TAMANHO_GRADE) shapes.line(x, 0, x, MUNDO_ALTURA);
        for (float y = 0; y <= MUNDO_ALTURA; y += TAMANHO_GRADE) shapes.line(0, y, MUNDO_LARGURA, y);
        shapes.setColor(Color.GRAY);
        shapes.rect(0, 0, MUNDO_LARGURA, MUNDO_ALTURA);

        // Altares: borda e progresso dos sacrificios
        for (int i = 0; i < altares.size; i++) {
            Altar altar = altares.get(i);
            shapes.setColor(Color.MAGENTA);
            shapes.circle(altar.posicao.x, altar.posicao.y, altar.raio);
            if (altar.progresso() > 0) {
                shapes.setColor(Color.GOLD);
                shapes.arc(altar.posicao.x, altar.posicao.y, altar.raio + 8, 90, 360 * altar.progresso());
            }
        }

        // Aviso dos meteoros: circulo vermelho com um circulo interno que cresce ate cair
        for (int i = 0; i < meteoros.size; i++) {
            Meteoro m = meteoros.get(i);
            if (m.caiu()) continue;
            shapes.setColor(Color.RED);
            shapes.circle(m.posicao.x, m.posicao.y, m.raio);
            shapes.circle(m.posicao.x, m.posicao.y, m.raio * m.progressoAviso());
        }

        // Aviso da investida do boss
        if (boss != null && boss.estaVivo() && boss.preparandoInvestida()) {
            shapes.setColor(Color.RED);
            shapes.circle(boss.posicao.x, boss.posicao.y, boss.tamanho * 0.75f);
            shapes.circle(boss.posicao.x, boss.posicao.y, boss.tamanho * 0.85f);
        }

        // Alcance do ataque basico e raio do ataque
        shapes.setColor(0.3f, 0.3f, 0.4f, 1f);
        shapes.circle(heroi.posicao.x, heroi.posicao.y, heroi.alcanceAtaque);
        if (tempoEfeitoAtaque > 0) {
            shapes.setColor(Color.YELLOW);
            for (int i = 0; i < linhasAtaque.size; i++) shapes.line(heroi.posicao, linhasAtaque.get(i));
        }

        // Efeitos dos poderes (explosoes, raios, ondas)
        for (int i = 0; i < heroi.poderes.size; i++) heroi.poderes.get(i).desenharLinhas(shapes, heroi);
        if (heroi.epico != null) heroi.epico.desenharLinhas(shapes, heroi);

        // Onda da habilidade especial em area
        float raio = heroi.getRaioHabilidade();
        if (heroi.getTempoEfeitoHabilidade() > 0 && raio > 0) {
            float progresso = 1f - heroi.getTempoEfeitoHabilidade() / heroi.getDuracaoEfeitoHabilidade();
            shapes.setColor(heroi.classe.cor);
            shapes.circle(heroi.posicao.x, heroi.posicao.y, raio * progresso);
        }

        // Aura da Furia do Demonio
        if (heroi.emFuria()) {
            shapes.setColor(Color.ORANGE);
            shapes.circle(heroi.posicao.x, heroi.posicao.y, heroi.tamanho * 0.9f);
            shapes.circle(heroi.posicao.x, heroi.posicao.y, heroi.tamanho * 1.0f);
        }

        shapes.end();
    }

    private void desenharFormasMundo() {
        shapes.begin(ShapeRenderer.ShapeType.Filled);

        // Chao dos altares (fica dourado quando completo)
        for (int i = 0; i < altares.size; i++) {
            Altar altar = altares.get(i);
            if (altar.completo()) shapes.setColor(0.35f, 0.28f, 0.05f, 1f);
            else shapes.setColor(0.22f, 0.08f, 0.28f, 1f);
            shapes.circle(altar.posicao.x, altar.posicao.y, altar.raio);
        }

        // Itens de vida no chao
        for (int i = 0; i < drops.size; i++) {
            ItemDrop d = drops.get(i);
            if (!d.visivel()) continue;
            shapes.setColor(Color.WHITE);
            shapes.circle(d.posicao.x, d.posicao.y, d.raio);
            shapes.setColor(Color.RED);
            shapes.circle(d.posicao.x, d.posicao.y, d.raio * 0.6f);
        }

        // Monstros (cor muda com o efeito: lento = azulado, queimando = alaranjado, atordoado = amarelo)
        for (int i = 0; i < monstros.size; i++) {
            Monstro m = monstros.get(i);
            float meio = m.tamanho / 2f;
            if (m.estaPiscando())       corTemp.set(Color.WHITE);
            else if (m.estaAtordoado()) corTemp.set(Color.YELLOW);
            else if (m.estaLento())     corTemp.set(m.cor).lerp(Color.CYAN, 0.5f);
            else if (m.estaQueimando()) corTemp.set(m.cor).lerp(Color.ORANGE, 0.5f);
            else                        corTemp.set(m.cor);
            if (m instanceof Boss && ((Boss) m).emInvestida()) corTemp.lerp(Color.RED, 0.5f);
            shapes.setColor(corTemp);
            shapes.rect(m.posicao.x - meio, m.posicao.y - meio, m.tamanho, m.tamanho);

            float porcentagem = Math.max(0, m.vida / m.vidaMaxima);
            shapes.setColor(Color.DARK_GRAY);
            shapes.rect(m.posicao.x - meio, m.posicao.y + meio + 3, m.tamanho, 4);
            shapes.setColor(Color.RED);
            shapes.rect(m.posicao.x - meio, m.posicao.y + meio + 3, m.tamanho * porcentagem, 4);
        }

        // Meteoros caindo (explosao)
        for (int i = 0; i < meteoros.size; i++) {
            Meteoro m = meteoros.get(i);
            if (!m.caiu()) continue;
            shapes.setColor(Color.ORANGE);
            shapes.circle(m.posicao.x, m.posicao.y, m.raio);
            shapes.setColor(Color.YELLOW);
            shapes.circle(m.posicao.x, m.posicao.y, m.raio * 0.5f);
        }

        // Tiros do boss
        for (int i = 0; i < projeteisInimigos.size; i++) {
            ProjetilInimigo p = projeteisInimigos.get(i);
            shapes.setColor(Color.VIOLET);
            shapes.circle(p.posicao.x, p.posicao.y, p.raio);
            shapes.setColor(Color.WHITE);
            shapes.circle(p.posicao.x, p.posicao.y, p.raio * 0.4f);
        }

        // Projeteis
        for (int i = 0; i < projeteis.size; i++) {
            Projetil p = projeteis.get(i);
            shapes.setColor(p.cor);
            shapes.circle(p.posicao.x, p.posicao.y, p.raio);
        }

        // Heroi (pisca em branco quando esta invencivel)
        float meioHeroi = heroi.tamanho / 2f;
        shapes.setColor(heroi.estaInvencivel() ? Color.WHITE : heroi.classe.cor);
        shapes.rect(heroi.posicao.x - meioHeroi, heroi.posicao.y - meioHeroi, heroi.tamanho, heroi.tamanho);

        // Efeitos preenchidos dos poderes (laminas de vento, feixe de luz)
        for (int i = 0; i < heroi.poderes.size; i++) heroi.poderes.get(i).desenharFormas(shapes, heroi);
        if (heroi.epico != null) heroi.epico.desenharFormas(shapes, heroi);

        shapes.end();

        // Texto do altar (no mundo)
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        fonte.setColor(Color.WHITE);
        for (int i = 0; i < altares.size; i++) {
            Altar altar = altares.get(i);
            String textoAltar = altar.completo() ? "ALTAR COMPLETO" : "ALTAR " + altar.getSacrificios() + "/" + altar.getNecessario();
            fonte.draw(batch, textoAltar, altar.posicao.x - 70, altar.posicao.y + altar.raio + 24, 140, Align.center, false);
        }
        batch.end();
    }

    /** Seta na borda da tela apontando para algo fora da visao (altar, boss). */
    private void desenharSeta(Vector2 alvo, Color cor) {
        float dx = alvo.x - camera.position.x;
        float dy = alvo.y - camera.position.y;
        float meioL = LARGURA / 2f - 30f;
        float meioA = ALTURA / 2f - 30f;
        if (Math.abs(dx) <= meioL + 30f && Math.abs(dy) <= meioA + 30f) return; // ja esta na tela
        float escala = Math.min(meioL / Math.max(Math.abs(dx), 0.001f), meioA / Math.max(Math.abs(dy), 0.001f));
        float x = LARGURA / 2f + dx * escala;
        float y = ALTURA / 2f + dy * escala;
        float ang = MathUtils.atan2(dy, dx);
        shapes.setColor(cor);
        shapes.circle(x, y, 9f);
        shapes.triangle(
            x + MathUtils.cos(ang) * 20f, y + MathUtils.sin(ang) * 20f,
            x + MathUtils.cos(ang + 2.4f) * 10f, y + MathUtils.sin(ang + 2.4f) * 10f,
            x + MathUtils.cos(ang - 2.4f) * 10f, y + MathUtils.sin(ang - 2.4f) * 10f);
    }

    private void desenharHud() {
        shapes.begin(ShapeRenderer.ShapeType.Filled);

        // Barra de vida
        shapes.setColor(Color.DARK_GRAY);
        shapes.rect(10, ALTURA - 24, 200, 14);
        shapes.setColor(Color.GREEN);
        shapes.rect(10, ALTURA - 24, 200 * (heroi.vida / heroi.vidaMaxima), 14);

        // Botao da habilidade
        shapes.setColor(heroi.habilidadePronta() ? heroi.classe.cor : Color.DARK_GRAY);
        shapes.circle(BOTAO_X, BOTAO_Y, BOTAO_RAIO);

        // Botao do epico
        if (heroi.epico != null) {
            if (heroi.epico.ativo())       shapes.setColor(Color.WHITE);
            else if (heroi.epico.pronto()) shapes.setColor(heroi.epico.tipo.cor);
            else                           shapes.setColor(Color.DARK_GRAY);
            shapes.circle(BOTAO_EPICO_X, BOTAO_Y, BOTAO_EPICO_RAIO);
        }

        // Barra de vida do boss
        if (boss != null && boss.estaVivo()) {
            shapes.setColor(Color.DARK_GRAY);
            shapes.rect(200, ALTURA - 52, 400, 12);
            shapes.setColor(Color.PURPLE);
            shapes.rect(200, ALTURA - 52, 400 * Math.max(0, boss.vida / boss.vidaMaxima), 12);
            desenharSeta(boss.posicao, Color.PURPLE);
        } else if (boss == null && !bossDerrotado) {
            for (int i = 0; i < altares.size; i++) {
                if (!altares.get(i).completo()) desenharSeta(altares.get(i).posicao, Color.MAGENTA);
            }
        }

        shapes.end();
    }

    private void desenharTextos() {
        batch.begin();
        fonte.setColor(Color.WHITE);

        // HUD (a fonte padrao nao tem acentos, por isso os textos estao sem eles)
        fonte.draw(batch, "Vida: " + (int) heroi.vida + "/" + (int) heroi.vidaMaxima, 220, ALTURA - 12);
        fonte.draw(batch, "Horda: " + hordas.getHordaAtual() + "/" + hordas.getTotalHordas(), 360, ALTURA - 12);
        fonte.draw(batch, "Abates: " + abates, 480, ALTURA - 12);
        fonte.draw(batch, "Altares: " + totalSacrificios() + "/" + totalNecessario(), 580, ALTURA - 12);
        if (boss != null && boss.estaVivo()) {
            fonte.draw(batch, "BOSS: " + boss.nome + (boss.enraivecido() ? "  (ENRAIVECIDO!)" : ""), 0, ALTURA - 58, LARGURA, Align.center, false);
        }
        fonte.draw(batch, heroi.nomeClasse, 0, ALTURA - 12, LARGURA - 10, Align.right, false);

        // Poderes ativos
        StringBuilder sb = new StringBuilder("Poderes: ");
        if (heroi.poderes.size == 0) sb.append("escolha o primeiro ao fim da horda 1");
        for (int i = 0; i < heroi.poderes.size; i++) {
            Poder p = heroi.poderes.get(i);
            if (i > 0) sb.append("  |  ");
            sb.append(p.tipo.nome).append(" Nv").append(p.getNivel());
        }
        if (heroi.elemento != null) sb.append("   [Elemento: ").append(heroi.elemento.nome).append("]");
        fonte.draw(batch, sb.toString(), 10, 42);
        fonte.draw(batch, heroi.classe.nomeHabilidade + "  [ESPACO]", 10, 20);
        if (heroi.epico != null) {
            fonte.draw(batch, "Epico: " + heroi.epico.tipo.nome + " Nv" + heroi.epico.getNivel() + "  [E]", 10, 64);
            String textoEpico = heroi.epico.ativo() ? (int) Math.ceil(heroi.epico.getTempoAtivo()) + "s"
                : heroi.epico.pronto() ? "EPICO" : String.valueOf((int) Math.ceil(heroi.epico.getRecarga()));
            fonte.setColor(heroi.epico.ativo() || heroi.epico.pronto() ? Color.BLACK : Color.WHITE);
            fonte.draw(batch, textoEpico, BOTAO_EPICO_X - BOTAO_EPICO_RAIO, BOTAO_Y + 6, BOTAO_EPICO_RAIO * 2, Align.center, false);
            fonte.setColor(Color.WHITE);
        }

        // Texto do botao: "HAB" quando pronta, segundos restantes quando recarregando
        String textoBotao = heroi.habilidadePronta() ? "HAB" : String.valueOf((int) Math.ceil(heroi.getRecargaRestante()));
        fonte.setColor(heroi.habilidadePronta() ? Color.BLACK : Color.WHITE);
        fonte.draw(batch, textoBotao, BOTAO_X - BOTAO_RAIO, BOTAO_Y + 6, BOTAO_RAIO * 2, Align.center, false);

        fonte.setColor(Color.WHITE);
        if (!heroi.estaVivo()) {
            fonte.draw(batch, "VOCE MORREU!", 0, ALTURA / 2f + 20, LARGURA, Align.center, false);
            fonte.draw(batch, "R = recomecar   |   ESC ou toque = trocar de classe", 0, ALTURA / 2f - 5, LARGURA, Align.center, false);
        } else if (faseConcluida) {
            fonte.draw(batch, "FASE CONCLUIDA!", 0, ALTURA / 2f + 20, LARGURA, Align.center, false);
            fonte.draw(batch, "R = jogar de novo  |  C = continuar no modo infinito (testar o epico)  |  ESC = trocar de classe",
                0, ALTURA / 2f - 5, LARGURA, Align.center, false);
        } else if (hordas.concluida() && boss == null && !bossDerrotado && !escolhendoRecompensa()) {
            fonte.draw(batch, "HORDAS VENCIDAS! Complete os 2 ALTARES para invocar o BOSS ("
                + totalSacrificios() + "/" + totalNecessario() + ")", 0, ALTURA / 2f + 60, LARGURA, Align.center, false);
        } else if (tempoAvisoAltar > 0 && !escolhendoRecompensa()) {
            fonte.draw(batch, "UM ALTAR MUDOU DE LUGAR! Siga as setas roxas.", 0, ALTURA / 2f + 60, LARGURA, Align.center, false);
        } else if (hordas.emIntervalo() && !escolhendoRecompensa()) {
            int proxima = hordas.getHordaAtual() + 1;
            fonte.draw(batch, "Prepare-se! Horda " + proxima + " em " + (int) Math.ceil(hordas.getTempoIntervalo()) + "...",
                0, ALTURA / 2f + 60, LARGURA, Align.center, false);
        }
        batch.end();
    }

    private void desenharEscolha() {
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        shapes.setColor(0f, 0f, 0f, 0.7f);
        shapes.rect(0, 0, LARGURA, ALTURA); // escurece o jogo por tras

        for (int i = 0; i < opcoes.size; i++) {
            Rectangle c = cards.get(i);
            Recompensa r = opcoes.get(i);
            boolean pequeno = c.height < 100;
            shapes.setColor(0.16f, 0.16f, 0.20f, 1f);
            shapes.rect(c.x, c.y, c.width, c.height);
            shapes.setColor(r.getCor());
            shapes.rect(c.x, c.y + c.height - (pequeno ? 22 : 30), c.width, pequeno ? 22 : 30);
            if (!pequeno) shapes.circle(c.x + c.width / 2f, c.y + c.height - 75, 24); // "icone"
        }
        shapes.end();
        Gdx.gl.glDisable(GL20.GL_BLEND);

        batch.begin();
        fonte.setColor(Color.WHITE);
        fonte.draw(batch, tituloEscolha(), 0, ALTURA - 70, LARGURA, Align.center, false);
        fonte.draw(batch, "Clique/toque no card ou aperte o numero", 0, 90, LARGURA, Align.center, false);
        for (int i = 0; i < opcoes.size; i++) {
            Rectangle c = cards.get(i);
            Recompensa r = opcoes.get(i);
            boolean pequeno = c.height < 100;
            fonte.setColor(Color.BLACK);
            fonte.draw(batch, (i + 1) + ". " + r.getNome(), c.x, c.y + c.height - (pequeno ? 5 : 9), c.width, Align.center, false);
            fonte.setColor(Color.WHITE);
            float yDescricao = pequeno ? c.y + c.height - 30 : c.y + 75;
            fonte.draw(batch, r.getDescricao(), c.x + 8, yDescricao, c.width - 16, Align.center, true);
        }
        batch.end();
    }

    private String tituloEscolha() {
        switch (modo) {
            case PRIMEIRO_PODER: return "HORDA CONCLUIDA! ESCOLHA SEU PRIMEIRO PODER";
            case ELEMENTO:       return "HORDA CONCLUIDA! ESCOLHA O ELEMENTO DA SUA ARMA";
            case TROCA_ELEMENTO: return "MUDAR ELEMENTO: ESCOLHA O NOVO ELEMENTO";
            case BOSS:           return "BOSS DERROTADO! ESCOLHA SUA RECOMPENSA";
            case PERDER_BUFF:    return "PENALIDADE: ESCOLHA UM BUFF PARA PERDER (faltam " + heroi.penalidadesPendentes + ")";
            default:             return "HORDA CONCLUIDA! ESCOLHA UMA RECOMPENSA";
        }
    }

    @Override
    public void resize(int width, int height) {
        if (width <= 0 || height <= 0) return;
        viewport.update(width, height, false);
        viewportHud.update(width, height, true);
    }

    @Override
    public void dispose() {
        shapes.dispose();
        batch.dispose();
        fonte.dispose();
    }
}
