package com.hemerson.FujaSePuder.entidades;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.itens.TipoBuff;
import com.hemerson.FujaSePuder.poderes.ElementoArma;
import com.hemerson.FujaSePuder.poderes.Poder;
import com.hemerson.FujaSePuder.poderes.PoderEpico;
import com.hemerson.FujaSePuder.poderes.TipoEpico;
import com.hemerson.FujaSePuder.poderes.TipoPoder;

/** O personagem controlado pelo jogador. A posicao e o CENTRO do quadrado. */
public class Heroi {

    private static final float DURACAO_EFEITO_HABILIDADE = 0.3f;
    private static final float DURACAO_FURIA = 5f;
    /** Roubo de vida do Demonio: no maximo isso de cura por segundo. */
    private static final float LIMITE_ROUBO_POR_SEGUNDO = 2f;
    public static final int MAX_PODERES = 3;

    public ClasseHeroi classe;                 // pode mudar na troca de classe do boss
    public String nomeClasse;                  // ex.: "Anjo Caido" depois da troca
    public boolean jaTrocouDeClasse = false;
    public PoderEpico epico = null;            // ganho no boss
    public final Vector2 posicao = new Vector2();
    public final float tamanho = 32f;
    public final Array<Poder> poderes = new Array<>();
    /** Buffs permanentes pegos (podem repetir). */
    public final Array<TipoBuff> buffs = new Array<>();

    // Elemento da arma (so Humano) e niveis das 2 melhorias do elemento
    public ElementoArma elemento = null;
    public final int[] niveisElemento = new int[2];

    // Pedidos que a TelaJogo resolve abrindo telas de escolha
    public boolean pedidoTrocaElemento = false;
    public int penalidadesPendentes = 0; // quantos buffs ainda precisa escolher para perder

    // Atributos (os buffs alteram esses valores)
    public float velocidade;
    public float vidaMaxima;
    public float vida;
    public float dano;            // comparado com o da classe para dar o multiplicador de dano dos poderes
    public float alcanceAtaque;   // idem para o alcance
    public float intervaloAtaque; // idem para a velocidade de ataque
    public float multiplicadorRecarga = 1f; // 0.85 = habilidade recarrega 15% mais rapido
    public float reducaoDano = 0f;          // 0.10 = recebe 10% menos dano

    private float tempoDesdeAtaque = 0f;
    private float tempoInvencivel = 0f;
    private float recargaRestante = 0f;
    private float furiaRestante = 0f;
    private float tempoEfeitoHabilidade = 0f;
    private float roubadoNoSegundo = 0f;
    private float tempoJanelaRoubo = 0f;

    public Heroi(float x, float y, ClasseHeroi classe) {
        this.classe = classe;
        this.nomeClasse = classe.nome;
        posicao.set(x, y);
        velocidade = classe.velocidade;
        vidaMaxima = classe.vidaMaxima;
        vida = vidaMaxima;
        dano = classe.dano;
        alcanceAtaque = classe.alcanceAtaque;
        intervaloAtaque = classe.intervaloAtaque;
    }

    /** Volta aos atributos da classe e reaplica todos os buffs guardados. */
    public void recalcularAtributos() {
        velocidade = classe.velocidade;
        vidaMaxima = classe.vidaMaxima;
        dano = classe.dano;
        alcanceAtaque = classe.alcanceAtaque;
        intervaloAtaque = classe.intervaloAtaque;
        multiplicadorRecarga = 1f;
        reducaoDano = 0f;
        for (int i = 0; i < buffs.size; i++) buffs.get(i).modificar(this);
        vida = Math.min(vida, vidaMaxima);
    }

    public int nivelElemento(int espaco) {
        return niveisElemento[espaco];
    }

    public void atualizar(float delta) {
        tempoDesdeAtaque += delta;
        if (tempoInvencivel > 0) tempoInvencivel -= delta;
        if (recargaRestante > 0) recargaRestante -= delta;
        if (furiaRestante > 0) furiaRestante -= delta;
        if (tempoEfeitoHabilidade > 0) tempoEfeitoHabilidade -= delta;

        tempoJanelaRoubo += delta;
        if (tempoJanelaRoubo >= 1f) {
            tempoJanelaRoubo = 0f;
            roubadoNoSegundo = 0f;
        }

        // Passiva do Humano: 1 de vida a cada 2s
        if (classe == ClasseHeroi.HUMANO && estaVivo()) curar(0.5f * delta);
    }

    // ------------------------------------------------------ multiplicadores dos poderes

    /** 1.0 = normal. Sobe com buffs de dano e com a Furia do Demonio. */
    public float fatorDano() {
        float f = dano / classe.dano;
        if (formaInfernalAtiva()) f *= 1.3f;
        return emFuria() ? f * 1.25f : f;
    }

    /** 1.0 = normal. Menor = poderes recarregam mais rapido. */
    public float fatorVelocidadeAtaque() {
        float f = intervaloAtaque / classe.intervaloAtaque;
        return emFuria() ? f * 0.5f : f;
    }

    /** 1.0 = normal. Sobe com buffs de alcance. */
    public float fatorAlcance() {
        return alcanceAtaque / classe.alcanceAtaque;
    }

    // ------------------------------------------------------------- ataque basico

    public float getDanoAtual() {
        float d = formaInfernalAtiva() ? dano * 1.3f : dano;
        return emFuria() ? d * 1.25f : d;
    }

    /** Epico do Demonio ativo: +30% de dano. */
    public boolean formaInfernalAtiva() {
        return epico != null && epico.tipo == TipoEpico.FORMA_INFERNAL && epico.ativo();
    }

    // ------------------------------------------------------------- troca de classe

    /**
     * Troca de classe (boss). Os poderes viram os equivalentes da nova classe no nivel 1.
     * Virando Humano: o 1o poder vira Pistola e o 2o vira Dupla; o elemento vem do papel do 1o poder
     * (dano = Laser, controle = Gelo, area = Fogo). A penalidade (perder 2 buffs) e resolvida pela TelaJogo.
     */
    public void trocarClasse(ClasseHeroi nova, String nomeTransformacao) {
        Array<TipoPoder> antigos = new Array<>();
        for (int i = 0; i < poderes.size; i++) antigos.add(poderes.get(i).tipo);
        poderes.clear();

        ElementoArma novoElemento = null;
        if (nova == ClasseHeroi.HUMANO) {
            TipoPoder[] armas = { TipoPoder.PISTOLA, TipoPoder.DUPLA };
            for (int i = 0; i < Math.min(2, antigos.size); i++) adicionarPoder(armas[i].criar());
            if (antigos.size > 0) {
                int papel = antigos.first().papel;
                novoElemento = papel == 1 ? ElementoArma.GELO : papel == 2 ? ElementoArma.FOGO : ElementoArma.LASER;
            }
        } else {
            for (int i = 0; i < antigos.size; i++) {
                TipoPoder eq = TipoPoder.equivalente(antigos.get(i), nova);
                if (eq != null && !temPoder(eq)) adicionarPoder(eq.criar());
            }
        }

        float porcentagemVida = vida / vidaMaxima;
        classe = nova;
        nomeClasse = nomeTransformacao;
        elemento = novoElemento;
        niveisElemento[0] = 0;
        niveisElemento[1] = 0;
        recalcularAtributos();
        vida = vidaMaxima * porcentagemVida;

        recargaRestante = 0f;
        furiaRestante = 0f;
        jaTrocouDeClasse = true;
        penalidadesPendentes += 2;
        if (epico != null) epico.tipo = TipoEpico.para(this);
    }

    public float getIntervaloAtual() {
        return emFuria() ? intervaloAtaque * 0.5f : intervaloAtaque;
    }

    public boolean podeAtacar() {
        return tempoDesdeAtaque >= getIntervaloAtual();
    }

    public void registrarAtaque() {
        tempoDesdeAtaque = 0f;
    }

    /** Passiva do Anjo: o ataque basico acerta 2 monstros. */
    public int alvosPorAtaque() {
        return classe == ClasseHeroi.ANJO ? 2 : 1;
    }

    /** Chamado sempre que o heroi causa dano. Passiva do Demonio: roubo de vida limitado. */
    public void aoCausarDano(float danoCausado) {
        if (classe == ClasseHeroi.DEMONIO) {
            float cura = Math.min(danoCausado * 0.05f, LIMITE_ROUBO_POR_SEGUNDO - roubadoNoSegundo);
            if (cura > 0) {
                curar(cura);
                roubadoNoSegundo += cura;
            }
        }
    }

    // ------------------------------------------------------------------ poderes

    public Poder getPoder(TipoPoder tipo) {
        for (int i = 0; i < poderes.size; i++) {
            if (poderes.get(i).tipo == tipo) return poderes.get(i);
        }
        return null;
    }

    public boolean temPoder(TipoPoder tipo) {
        return getPoder(tipo) != null;
    }

    public void adicionarPoder(Poder poder) {
        if (poderes.size < MAX_PODERES && !temPoder(poder.tipo)) poderes.add(poder);
    }

    // ---------------------------------------------------------------- habilidade

    public boolean habilidadePronta() {
        return recargaRestante <= 0;
    }

    /** Usa a habilidade especial da classe. Retorna false se ainda estiver recarregando. */
    public boolean usarHabilidade(Array<Monstro> monstros) {
        if (!habilidadePronta() || !estaVivo()) return false;

        switch (classe) {
            case HUMANO:
                causarDanoEmArea(monstros, getRaioHabilidade(), 40f);
                break;
            case DEMONIO:
                furiaRestante = DURACAO_FURIA;
                break;
            case ANJO:
                curar(30f);
                causarDanoEmArea(monstros, getRaioHabilidade(), 30f);
                break;
        }

        recargaRestante = classe.recargaHabilidade * multiplicadorRecarga;
        tempoEfeitoHabilidade = DURACAO_EFEITO_HABILIDADE;
        return true;
    }

    private void causarDanoEmArea(Array<Monstro> monstros, float raio, float quantidade) {
        for (int i = 0; i < monstros.size; i++) {
            Monstro m = monstros.get(i);
            if (m.posicao.dst(posicao) <= raio) {
                m.receberDano(quantidade);
                aoCausarDano(quantidade);
            }
        }
    }

    /** Raio do efeito em area (0 para habilidades sem area). */
    public float getRaioHabilidade() {
        switch (classe) {
            case HUMANO: return 130f;
            case ANJO:   return 220f;
            default:     return 0f;
        }
    }

    // --------------------------------------------------------------- vida / estado

    public void receberDano(float quantidade) {
        if (tempoInvencivel > 0) return; // meio segundo de invencibilidade apos levar dano
        vida = Math.max(0, vida - quantidade * (1f - reducaoDano));
        tempoInvencivel = 0.5f;
    }

    public void curar(float quantidade) {
        vida = Math.min(vidaMaxima, vida + quantidade);
    }

    public boolean estaVivo() { return vida > 0; }
    public boolean estaInvencivel() { return tempoInvencivel > 0; }
    public boolean emFuria() { return furiaRestante > 0; }
    public float getRecargaRestante() { return Math.max(0, recargaRestante); }
    public float getTempoEfeitoHabilidade() { return tempoEfeitoHabilidade; }
    public float getDuracaoEfeitoHabilidade() { return DURACAO_EFEITO_HABILIDADE; }
}
