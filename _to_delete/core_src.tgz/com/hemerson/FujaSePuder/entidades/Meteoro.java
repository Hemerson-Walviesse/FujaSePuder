package com.hemerson.FujaSePuder.entidades;

import com.badlogic.gdx.math.Vector2;

/** Meteoro do boss: marca o chao (aviso vermelho) e cai depois de um tempo, causando dano em area. */
public class Meteoro {
    public static final float TEMPO_AVISO = 1.2f;
    public static final float TEMPO_EXPLOSAO = 0.25f;

    public final Vector2 posicao = new Vector2();
    public final float raio;
    public final float dano;
    private float tempo = 0f;
    private boolean caiu = false;

    public Meteoro(float x, float y, float raio, float dano) {
        posicao.set(x, y);
        this.raio = raio;
        this.dano = dano;
    }

    /** Retorna true no instante exato em que o meteoro cai. */
    public boolean atualizar(float delta) {
        tempo += delta;
        if (!caiu && tempo >= TEMPO_AVISO) {
            caiu = true;
            return true;
        }
        return false;
    }

    /** 0 quando aparece o aviso, 1 quando cai. */
    public float progressoAviso() { return Math.min(1f, tempo / TEMPO_AVISO); }
    public boolean caiu() { return caiu; }
    public boolean terminou() { return tempo >= TEMPO_AVISO + TEMPO_EXPLOSAO; }

    public boolean atinge(Heroi heroi) {
        return posicao.dst(heroi.posicao) <= raio + heroi.tamanho / 2f;
    }
}
