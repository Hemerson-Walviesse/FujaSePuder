package com.hemerson.FujaSePuder.entidades;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;

/**
 * Boss: grande, muita vida, resiste a controle (25% do efeito de lentidao/atordoar/empurrao).
 * Ataques:
 *  - Investida: a cada 4s para, mostra contorno vermelho e avanca rapido.
 *  - Rajada: tiros em todas as direcoes (12; 16 quando enraivecido).
 *  - Chuva de meteoros: marca o chao perto do heroi e cai depois de 1.2s (5; 7 quando enraivecido).
 * Abaixo de 50% de vida fica ENRAIVECIDO: ataques mais frequentes.
 * A TelaJogo cria os tiros/meteoros quando consumirRajada()/consumirMeteoros() retornam true.
 */
public class Boss extends Monstro {

    private static final float INTERVALO_INVESTIDA = 4f;
    private static final float TEMPO_PREPARACAO = 0.7f;
    private static final float TEMPO_INVESTIDA = 0.6f;
    private static final float INTERVALO_RAJADA = 5f;
    private static final float INTERVALO_RAJADA_RAIVA = 3.5f;
    private static final float INTERVALO_METEOROS = 7f;
    private static final float INTERVALO_METEOROS_RAIVA = 5f;

    public final String nome;
    private float tempoProximaInvestida = INTERVALO_INVESTIDA;
    private float tempoPreparando = 0f;
    private float tempoInvestida = 0f;
    private float tempoRajada = 2.5f;
    private float tempoMeteoros = 5f;
    private boolean pedidoRajada = false;
    private boolean pedidoMeteoros = false;

    public Boss(float x, float y, String nome, float vida) {
        super(x, y, vida, 65f, 25f, 80f, Color.PURPLE, 0f);
        this.nome = nome;
        this.resistenciaControle = 0.25f;
    }

    @Override
    public void atualizar(float delta, Vector2 alvo) {
        // Investida
        if (tempoPreparando > 0) {
            tempoPreparando -= delta;
            multiplicadorVelocidade = 0f;
            if (tempoPreparando <= 0) tempoInvestida = TEMPO_INVESTIDA;
        } else if (tempoInvestida > 0) {
            tempoInvestida -= delta;
            multiplicadorVelocidade = 4.5f;
        } else {
            multiplicadorVelocidade = 1f;
            tempoProximaInvestida -= delta;
            if (tempoProximaInvestida <= 0) {
                tempoProximaInvestida = INTERVALO_INVESTIDA;
                tempoPreparando = TEMPO_PREPARACAO;
            }
        }

        // Rajada e meteoros
        tempoRajada -= delta;
        if (tempoRajada <= 0) {
            pedidoRajada = true;
            tempoRajada = enraivecido() ? INTERVALO_RAJADA_RAIVA : INTERVALO_RAJADA;
        }
        tempoMeteoros -= delta;
        if (tempoMeteoros <= 0) {
            pedidoMeteoros = true;
            tempoMeteoros = enraivecido() ? INTERVALO_METEOROS_RAIVA : INTERVALO_METEOROS;
        }

        super.atualizar(delta, alvo);
    }

    public boolean consumirRajada() {
        boolean r = pedidoRajada;
        pedidoRajada = false;
        return r;
    }

    public boolean consumirMeteoros() {
        boolean r = pedidoMeteoros;
        pedidoMeteoros = false;
        return r;
    }

    public boolean enraivecido() { return vida < vidaMaxima * 0.5f; }
    public boolean preparandoInvestida() { return tempoPreparando > 0; }
    public boolean emInvestida() { return tempoInvestida > 0; }
}
