package com.hemerson.FujaSePuder.entidades;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;

/** Um monstro que persegue o heroi. A posicao e o CENTRO do quadrado. */
public class Monstro {
    public final Vector2 posicao = new Vector2();
    public final float tamanho;
    public final float velocidade;
    public final float vidaMaxima;
    public float vida;
    public final float dano;
    public final Color cor;
    /** Chance de soltar um item ao morrer (0.2 = 20%). */
    public final float chanceDrop;

    /** Usado pelas laminas de vento do Anjo para nao acertar o mesmo monstro todo frame. */
    public float tempoImuneOrbita = 0f;

    /** Usado pelo boss na investida (1 = normal). */
    protected float multiplicadorVelocidade = 1f;
    /** 1 = sofre controle normal; 0.25 = lentidao/atordoar/empurrao com 25% do efeito (boss). */
    protected float resistenciaControle = 1f;

    private final Vector2 direcao = new Vector2();
    private final Vector2 empurrao = new Vector2();
    private float tempoPiscando = 0f;

    // Efeitos de status
    private float fatorLentidao = 1f;
    private float tempoLentidao = 0f;
    private float danoQueimaduraPorSegundo = 0f;
    private float tempoQueimadura = 0f;
    private float tempoAtordoado = 0f;

    public Monstro(float x, float y, float vida, float velocidade, float dano, float tamanho, Color cor, float chanceDrop) {
        this.posicao.set(x, y);
        this.vidaMaxima = vida;
        this.vida = vida;
        this.velocidade = velocidade;
        this.dano = dano;
        this.tamanho = tamanho;
        this.cor = cor;
        this.chanceDrop = chanceDrop;
    }

    public void atualizar(float delta, Vector2 alvo) {
        if (tempoPiscando > 0) tempoPiscando -= delta;
        if (tempoImuneOrbita > 0) tempoImuneOrbita -= delta;

        if (tempoLentidao > 0) {
            tempoLentidao -= delta;
            if (tempoLentidao <= 0) fatorLentidao = 1f;
        }
        if (tempoQueimadura > 0) {
            tempoQueimadura -= delta;
            vida -= danoQueimaduraPorSegundo * delta;
        }

        if (tempoAtordoado > 0) {
            tempoAtordoado -= delta; // parado
        } else {
            direcao.set(alvo).sub(posicao);
            if (direcao.len2() > 1f) {
                direcao.nor().scl(velocidade * fatorLentidao * multiplicadorVelocidade * delta);
                posicao.add(direcao);
            }
        }

        // Empurrao (vento do Demonio) vai perdendo forca
        if (!empurrao.isZero(1f)) {
            posicao.mulAdd(empurrao, delta);
            empurrao.scl(Math.max(0f, 1f - 6f * delta));
        }
    }

    public void receberDano(float quantidade) {
        vida -= quantidade;
        tempoPiscando = 0.1f;
    }

    public void aplicarLentidao(float fator, float duracao) {
        fator = 1f - (1f - fator) * resistenciaControle;
        fatorLentidao = Math.min(fatorLentidao, fator);
        tempoLentidao = Math.max(tempoLentidao, duracao);
    }

    public void aplicarQueimadura(float danoPorSegundo, float duracao) {
        danoQueimaduraPorSegundo = Math.max(danoQueimaduraPorSegundo, danoPorSegundo);
        tempoQueimadura = Math.max(tempoQueimadura, duracao);
    }

    public void atordoar(float duracao) {
        tempoAtordoado = Math.max(tempoAtordoado, duracao * resistenciaControle);
    }

    public void empurrar(float forcaX, float forcaY) {
        empurrao.add(forcaX * resistenciaControle, forcaY * resistenciaControle);
    }

    public boolean estaVivo() { return vida > 0; }
    public boolean estaPiscando() { return tempoPiscando > 0; }
    public boolean estaLento() { return tempoLentidao > 0; }
    public boolean estaQueimando() { return tempoQueimadura > 0; }
    public boolean estaAtordoado() { return tempoAtordoado > 0; }

    public boolean colideCom(Heroi heroi) {
        return posicao.dst(heroi.posicao) < (tamanho + heroi.tamanho) / 2f;
    }
}
