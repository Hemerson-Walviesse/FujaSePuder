package com.hemerson.FujaSePuder.itens;

import com.badlogic.gdx.math.Vector2;
import com.hemerson.FujaSePuder.entidades.Heroi;

/** Item de vida que fica no chao depois que um monstro morre. Ao pegar, cura o heroi. */
public class ItemDrop {
    public static final float DURACAO = 20f; // some depois de 20s se ninguem pegar
    public final Vector2 posicao = new Vector2();
    public final float raio = 10f;
    private float tempoRestante = DURACAO;

    public ItemDrop(float x, float y) {
        posicao.set(x, y);
    }

    public void atualizar(float delta) {
        tempoRestante -= delta;
    }

    public boolean expirou() {
        return tempoRestante <= 0;
    }

    /** Pisca nos ultimos 5 segundos para avisar que vai sumir. */
    public boolean visivel() {
        return tempoRestante > 5f || ((int) (tempoRestante * 6)) % 2 == 0;
    }

    public boolean colideCom(Heroi heroi) {
        return posicao.dst(heroi.posicao) < raio + heroi.tamanho / 2f;
    }
}
