package com.hemerson.FujaSePuder.itens;

import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.Heroi;
import com.hemerson.FujaSePuder.poderes.ElementoArma;
import com.hemerson.FujaSePuder.poderes.Poder;
import com.hemerson.FujaSePuder.poderes.RecompensaPoder;
import com.hemerson.FujaSePuder.poderes.TipoPoder;

/** Monta as cartas da escolha de fim de horda: buffs + poderes novos + niveis de poder. */
public final class SorteioRecompensas {

    private SorteioRecompensas() { }

    public static Array<Recompensa> sortear(Heroi heroi, int quantidade) {
        Array<Recompensa> sacola = new Array<>();

        for (TipoBuff b : TipoBuff.values()) {
            if (b.disponivelPara(heroi.classe)) sacola.add(b);
        }

        // Cartas de poder entram 2x na sacola para aparecerem com mais frequencia
        for (TipoPoder t : TipoPoder.daClasse(heroi.classe)) {
            Poder p = heroi.getPoder(t);
            Recompensa carta = null;
            if (p == null && heroi.poderes.size < Heroi.MAX_PODERES) {
                carta = new RecompensaPoder(t, true, 1);
            } else if (p != null && !p.nivelMaximo()) {
                carta = new RecompensaPoder(t, false, p.getNivel() + 1);
            }
            if (carta != null) {
                sacola.add(carta);
                sacola.add(carta);
            }
        }

        // Humano: so aparecem melhorias do elemento escolhido (2x na sacola) e, as vezes, a troca
        if (heroi.elemento != null) {
            for (int espaco = 0; espaco < 2; espaco++) {
                int nivel = heroi.niveisElemento[espaco];
                if (nivel < ElementoArma.NIVEL_MAXIMO_MELHORIA) {
                    Recompensa carta = new RecompensaMelhoriaElemento(heroi.elemento, espaco, nivel + 1);
                    sacola.add(carta);
                    sacola.add(carta);
                }
            }
            sacola.add(new RecompensaMudarElemento());
        }

        sacola.shuffle();
        Array<Recompensa> escolhidas = new Array<>();
        for (int i = 0; i < sacola.size && escolhidas.size < quantidade; i++) {
            if (!escolhidas.contains(sacola.get(i), true)) escolhidas.add(sacola.get(i));
        }
        return escolhidas;
    }
}
