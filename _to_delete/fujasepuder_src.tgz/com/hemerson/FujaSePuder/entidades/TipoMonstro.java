package com.hemerson.FujaSePuder.entidades;

/** Tipos de monstro. Cada fase acrescenta tipos novos (ver GerenciadorDeHordas). */
public enum TipoMonstro {
    COMUM, CORREDOR, TANQUE,
    ATIRADOR,     // fase 2+: fica longe e atira
    FANTASMA,     // fase 3+: fica intangivel por instantes (so Luz e Raio/Laser acertam)
    BLINDADO,     // fase 4+: escudo que bloqueia 3 golpes e se regenera
    EXPLOSIVO,    // fase 5: explode ao morrer
    CURANDEIRO,   // fase 5: cura os monstros em volta
    LACAIO,       // invocado por bosses
    BOSS
}
