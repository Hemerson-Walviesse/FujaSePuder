package com.hemerson.FujaSePuder.hordas;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.hemerson.FujaSePuder.entidades.Monstro;
import com.hemerson.FujaSePuder.entidades.TipoMonstro;

/**
 * Controla as hordas de uma fase: intervalo entre hordas, quantos monstros nascem,
 * quais tipos aparecem e como a dificuldade cresce.
 *  - Cada horda: +15% de vida e dano.
 *  - Cada fase: +25% (multiplica) e traz um tipo novo de monstro.
 */
public class GerenciadorDeHordas {

    public enum Estado { INTERVALO, EM_ANDAMENTO, CONCLUIDA }

    /** Hordas por fase (fase 1 a 5). */
    private static final int[] HORDAS_POR_FASE = { 10, 12, 14, 17, 20 };

    private final int fase;
    private final int totalHordas;
    private final float larguraMundo;
    private final float alturaMundo;
    private final float fatorFase;

    private int hordaAtual = 0;
    private Estado estado = Estado.INTERVALO;
    private float tempoIntervalo = 2f;
    private int monstrosParaNascer = 0;
    private float tempoProximoSpawn = 0f;
    private boolean fimDeHordaPendente = false;

    public GerenciadorDeHordas(int fase, float larguraMundo, float alturaMundo) {
        this.fase = fase;
        this.totalHordas = HORDAS_POR_FASE[MathUtils.clamp(fase, 1, 5) - 1];
        this.larguraMundo = larguraMundo;
        this.alturaMundo = alturaMundo;
        this.fatorFase = (float) Math.pow(1.25, fase - 1);
    }

    public static float fatorDaFase(int fase) {
        return (float) Math.pow(1.25, fase - 1);
    }

    public void atualizar(float delta, Array<Monstro> monstros, Vector2 posicaoHeroi) {
        switch (estado) {
            case INTERVALO:
                tempoIntervalo -= delta;
                if (tempoIntervalo <= 0) iniciarProximaHorda();
                break;

            case EM_ANDAMENTO:
                if (monstrosParaNascer > 0) {
                    tempoProximoSpawn -= delta;
                    if (tempoProximoSpawn <= 0) {
                        monstros.add(criarMonstro(posicaoHeroi));
                        monstrosParaNascer--;
                        tempoProximoSpawn = intervaloEntreSpawns();
                    }
                } else if (monstros.isEmpty()) {
                    fimDeHordaPendente = true;
                    if (hordaAtual >= totalHordas) {
                        estado = Estado.CONCLUIDA;
                    } else {
                        estado = Estado.INTERVALO;
                        tempoIntervalo = 3f;
                    }
                }
                break;

            case CONCLUIDA:
                break;
        }
    }

    private void iniciarProximaHorda() {
        hordaAtual++;
        monstrosParaNascer = 4 + hordaAtual * 2;   // horda 1 = 6 monstros, horda 10 = 24, horda 20 = 44
        tempoProximoSpawn = 0f;
        estado = Estado.EM_ANDAMENTO;
    }

    private float intervaloEntreSpawns() {
        return Math.max(0.15f, 1.0f - hordaAtual * 0.06f);
    }

    /** +15% por horda, vezes o fator da fase (+25% por fase). */
    private float dificuldade() {
        return (1f + (hordaAtual - 1) * 0.15f) * fatorFase;
    }

    private Monstro criarMonstro(Vector2 posicaoHeroi) {
        // Nasce logo fora da area visivel, em uma direcao aleatoria a partir do heroi
        float angulo = MathUtils.random(MathUtils.PI2);
        float distancia = 500f + MathUtils.random(100f);
        float x = MathUtils.clamp(posicaoHeroi.x + MathUtils.cos(angulo) * distancia, 0, larguraMundo);
        float y = MathUtils.clamp(posicaoHeroi.y + MathUtils.sin(angulo) * distancia, 0, alturaMundo);

        float d = dificuldade();
        int h = hordaAtual;

        // Tipos novos das fases (sorteados primeiro)
        if (fase >= 5 && MathUtils.randomBoolean(0.08f))
            return new Monstro(x, y, 45 * d, 70 + h * 2, 5 * d, 26, Color.GOLDENROD, 0.30f).comTipo(TipoMonstro.CURANDEIRO);
        if (fase >= 5 && MathUtils.randomBoolean(0.10f))
            return new Monstro(x, y, 30 * d, 120 + h * 3, 10 * d, 24, Color.CORAL, 0.20f).comTipo(TipoMonstro.EXPLOSIVO);
        if (fase >= 4 && MathUtils.randomBoolean(0.12f))
            return new Monstro(x, y, 90 * d, 60 + h * 2, 15 * d, 38, Color.SLATE, 0.35f).comTipo(TipoMonstro.BLINDADO);
        if (fase >= 3 && MathUtils.randomBoolean(0.12f))
            return new Monstro(x, y, 40 * d, 100 + h * 3, 12 * d, 28, Color.LIGHT_GRAY, 0.25f).comTipo(TipoMonstro.FANTASMA);
        if (fase >= 2 && MathUtils.randomBoolean(0.15f))
            return new Monstro(x, y, 35 * d, 80 + h * 2, 8 * d, 26, Color.SALMON, 0.25f).comTipo(TipoMonstro.ATIRADOR);

        // Tanque (horda 5+ ou fase 2+)
        if ((h >= 5 || fase >= 2) && MathUtils.randomBoolean(0.15f))
            return new Monstro(x, y, 120 * d, 45 + h * 2, 20 * d, 44, Color.BROWN, 0.40f).comTipo(TipoMonstro.TANQUE);
        // Corredor (horda 3+ ou fase 2+)
        if ((h >= 3 || fase >= 2) && MathUtils.randomBoolean(0.25f))
            return new Monstro(x, y, 25 * d, 130 + h * 4, 8 * d, 22, Color.LIME, 0.30f).comTipo(TipoMonstro.CORREDOR);
        // Comum
        return new Monstro(x, y, 50 * d, 70 + h * 3, 10 * d, 30, Color.FOREST, 0.20f).comTipo(TipoMonstro.COMUM);
    }

    /** Monstro extra (dificuldade da horda atual), usado depois das hordas enquanto os altares nao enchem. */
    public Monstro criarMonstroExtra(Vector2 posicaoHeroi) {
        return criarMonstro(posicaoHeroi);
    }

    /** Retorna true uma unica vez logo depois que uma horda termina. */
    public boolean consumirFimDeHorda() {
        boolean terminou = fimDeHordaPendente;
        fimDeHordaPendente = false;
        return terminou;
    }

    public int getFase() { return fase; }
    public float getFatorFase() { return fatorFase; }
    public int getHordaAtual() { return hordaAtual; }
    public int getTotalHordas() { return totalHordas; }
    public float getTempoIntervalo() { return tempoIntervalo; }
    public boolean emIntervalo() { return estado == Estado.INTERVALO; }
    public boolean concluida() { return estado == Estado.CONCLUIDA; }
}
